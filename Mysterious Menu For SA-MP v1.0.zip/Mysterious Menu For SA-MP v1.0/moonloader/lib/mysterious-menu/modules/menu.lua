-- Mysterious Menu For SA:MP -  Mysterious Menu for Grand Theft Auto San Andreas Multiplayer
-- Copyright (C) 2022-2023 Mysterio

-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.

-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.

-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.

local module = {}

module.tmenu =
{	
	auto_reload 		= imgui.new.bool(fconfig.Get('tmenu.auto_reload',true)),
	auto_scale          = imgui.new.bool(fconfig.Get('tmenu.auto_scale',true)),
	command             = 
	{
		filter          = imgui.ImGuiTextFilter(),
		height          = 40,
		input_field     = imgui.new.char[256](),
		list            = {},
		show            = imgui.new.bool(false),
	},
	crash_text          = "",
	lock_player   		= imgui.new.bool(fconfig.Get('tmenu.lock_player',false)),
	overlay             = 
	{
		coordinates     = imgui.new.bool(fconfig.Get('tmenu.overlay.coordinates',false)),
		fps             = imgui.new.bool(fconfig.Get('tmenu.overlay.fps',false)),
		show            = imgui.new.bool(true),
		location    	= imgui.new.bool(fconfig.Get('tmenu.overlay.location',false)),
		offset          = imgui.new.int(10),
    	position        = {"Custom","Top Left","Top Right","Bottom Left","Bottom Right"},
    	position_array  = {},
		position_index  = imgui.new.int(fconfig.Get('tmenu.overlay.position_index',4)),
		health          = imgui.new.bool(fconfig.Get('tmenu.overlay.health',false)),
		pos_x           = imgui.new.int(fconfig.Get('tmenu.overlay.pos_x',0)),
		pos_y           = imgui.new.int(fconfig.Get('tmenu.overlay.pos_y',0)),
		speed           = imgui.new.bool(fconfig.Get('tmenu.overlay.speed',false)),		
	},
	show_tooltips	    = imgui.new.bool(fconfig.Get('tmenu.show_tooltips',true)),
	show_crash_message  = imgui.new.bool(fconfig.Get('tmenu.show_crash_message',true)),
}

module.tmenu.overlay.position_array = imgui.new['const char*'][#module.tmenu.overlay.position](module.tmenu.overlay.position)

--------------------------------------------------
-- Command window

function module.FindArgument(t,string)
    for k,v in ipairs(t) do
        if v == string then
            return true
        end
    end
    return false
end

function module.RegisterCommand(string,call_back_func,desc,usage)
    module.tmenu.command.list[string] = {call_back_func,desc,usage}
end

function module.ExecuteCommand()

    local string = ffi.string(module.tmenu.command.input_field)
	local t = {}
	
    for w in string:gmatch("%S+") do 
        table.insert(t,w)
	end
	
	for v,k in pairs(module.tmenu.command.list) do
        if v == t[1] then
            k[1](t)
            return
        end
	end
end

function module.RegisterAllCommands()

	module.RegisterCommand("reload",function(t)
		thisScript():reload()
	end,"Reload cheat menu")

	module.RegisterCommand("reloadall",function(t)
		reloadScripts()
	end,"Reload all moonloader scripts")
	
	module.RegisterCommand("cheatmenu",function(t)
        tcheatmenu.window.show[0] = not tcheatmenu.window.show[0]
    end,"Open or close cheat menu")

    module.RegisterCommand("copycoordinates",function(t)
        local x,y,z = getCharCoordinates(PLAYER_PED)
        setClipboardText(string.format("%s %s %s",math.floor(x),math.floor(y),math.floor(z)))
        printHelpString("Coordinates copied to clipboard")
    end,"Copies coordinates to clipboard")
end
--------------------------------------------------

function module.httpRequest(request, body, handler) -- copas.http
    -- start polling task
    if not copas.running then
        copas.running = true
        lua_thread.create(function()
            wait(0)
            while not copas.finished() do
                local ok, err = copas.step(0)
                if ok == nil then error(err) end
                wait(0)
            end
            copas.running = false
        end)
    end
    -- do request
    if handler then
        return copas.addthread(function(r, b, h)
            copas.setErrorHandler(function(err) h(nil, err) end)
            h(http.request(r, b))
        end, request, body, handler)
    else
        local results
        local thread = copas.addthread(function(r, b)
            copas.setErrorHandler(function(err) results = {nil, err} end)
            results = table.pack(http.request(r, b))
        end, request, body)
        while coroutine.status(thread) ~= 'dead' do wait(0) end
        return table.unpack(results)
    end
end

function module.GetPlayerLocation()
	local interior = getActiveInterior() 

	local town_name = "San Andreas"
	local city =  getCityPlayerIsIn(PLAYER_PED)

	if city == 0 then
		town_name = "CS"
	end
	if city == 1 then
		town_name = "LS"
	end
	if city == 2 then
		town_name = "SF"
	end
	if city == 3 then
		town_name = "LV"
	end

	if interior == 0 then

		local x,y,z = getCharCoordinates(PLAYER_PED)
		local zone_name = getGxtText(getNameOfZone(x,y,z))

		return string.format("Location: %s, %s",zone_name,town_name)
	else
		return string.format("Location: Interior %d, %s",getCharActiveInterior(PLAYER_PED),town_name)
	end
end

-- Main function
function module.MenuMain()

	fcommon.Tabs("Menu",{"Config","Overlay","Styles","License","About"},{
		function()
			if imgui.Button("Reset to Default",imgui.ImVec2(fcommon.GetSize(2))) then
				module.tmenu.crash_text = "Default Configuration ~g~Restored"
				fconfig.tconfig.reset = true
				thisScript():reload()
			end
			imgui.SameLine()
			if imgui.Button("Reload",imgui.ImVec2(fcommon.GetSize(2))) then
				module.tmenu.crash_text = "Mysterious Menu ~g~Reloaded"
				thisScript():reload()
			end
			imgui.Dummy(imgui.ImVec2(0,5))
			imgui.Columns(2,nil,false)
			fcommon.CheckBoxVar("Auto Reload",module.tmenu.auto_reload,"Reload Cheat Menu Automatically\nIn Case Of A Crash.\n\nMight Cause Crash Loop Sometimes.")
			fcommon.CheckBoxVar("Auto Scale",module.tmenu.auto_scale,"Automatically Scale Menu According To Size")	
			
			imgui.NextColumn()
			fcommon.CheckBoxVar("Lock Player",module.tmenu.lock_player,"Lock Player Controls While The Menu Is Open")
			fcommon.CheckBoxVar("Show Crash Message",module.tmenu.show_crash_message)
			fcommon.CheckBoxVar("Show Tooltips",module.tmenu.show_tooltips,"Shows Usage Tips Beside Options.")
			imgui.Columns(1)
			
		end,
		function()
			imgui.Columns(2,nil,false)
			fcommon.CheckBoxVar("Show Coordinates",module.tmenu.overlay.coordinates)
			fcommon.CheckBoxVar("Show FPS",module.tmenu.overlay.fps)	
			fcommon.CheckBoxVar("Show Location",module.tmenu.overlay.location)
			imgui.NextColumn()

			fcommon.CheckBoxVar("Show Vehicle Health",module.tmenu.overlay.health)
			fcommon.CheckBoxVar("Show Vehicle Speed",module.tmenu.overlay.speed)
			imgui.Columns(1)

			imgui.Spacing()
			imgui.Combo("Position", module.tmenu.overlay.position_index,module.tmenu.overlay.position_array,#module.tmenu.overlay.position)
			fcommon.InformationTooltip("You Can Also Right Click On The\nOverlay To Access These Options")
		end,
		function()
			if fstyle.tstyle.status then
				if imgui.Button("Delete Style",imgui.ImVec2(fcommon.GetSize(2))) then
					if fstyle.tstyle.list[fstyle.tstyle.selected[0] + 1] == nil then
						printHelpString("No Style Selected")
					else
						if fstyle.tstyle.list[fstyle.tstyle.selected[0] + 1] == "Default" then
							printHelpString("Can't Delete Default Style")
						else
							fstyle.tstyle.styles_table[(fstyle.tstyle.list[fstyle.tstyle.selected[0] + 1])] = nil
							fstyle.tstyle.list = fstyle.getStyles()
							fstyle.tstyle.array = imgui.new['const char*'][#fstyle.tstyle.list](fstyle.tstyle.list)
							fcommon.SaveJson("styles",fstyle.tstyle.styles_table)

							for k,v in ipairs(fstyle.tstyle.list) do
								if v == "Default" then
									fstyle.tstyle.selected[0] = k-1
								end
							end

							if fstyle.tstyle.list[fstyle.tstyle.selected[0]+1] == nil then
								fstyle.tstyle.selected[0] = fstyle.tstyle.selected[0] - 1
							end
							fstyle.applyStyle(imgui.GetStyle(), fstyle.tstyle.list[fstyle.tstyle.selected[0]+1])
							fstyle.tstyle.selected_name = fstyle.tstyle.list[fstyle.tstyle.selected[0]+1]
							printHelpString("Style Deleted")
						end
					end
				end
				imgui.SameLine()
				if imgui.Button("Save Style",imgui.ImVec2(fcommon.GetSize(2))) then
					fstyle.saveStyles(imgui.GetStyle(), ffi.string(fstyle.tstyle.list[fstyle.tstyle.selected[0] + 1]))
					fstyle.tstyle.list  = fstyle.getStyles()
					fstyle.tstyle.array = imgui.new['const char*'][#fstyle.tstyle.list](fstyle.tstyle.list)
					fstyle.applyStyle(imgui.GetStyle(), fstyle.tstyle.list[fstyle.tstyle.selected[0] + 1])
					fstyle.tstyle.selected_name = fstyle.tstyle.list[fstyle.tstyle.selected[0] + 1]
					printHelpString("Style Saved")
				end
			end

			imgui.Spacing()

			imgui.InputText('##styleName', fstyle.tstyle.name, ffi.sizeof(fstyle.tstyle.name) - 1) 
			imgui.SameLine()
			local vec_size = imgui.GetItemRectSize()
			vec_size.x = fcommon.GetSize(3)
			if imgui.Button("Add New Style",vec_size) then
				fstyle.saveStyles(imgui.GetStyle(), ffi.string(fstyle.tstyle.name))
				fstyle.tstyle.list = fstyle.getStyles()
				fstyle.tstyle.array = imgui.new['const char*'][#fstyle.tstyle.list](fstyle.tstyle.list)
				for k,v in ipairs(fstyle.tstyle.list) do
					if v == ffi.string(fstyle.tstyle.name) then
						fstyle.tstyle.selected[0] = k-1
					end
				end
				fstyle.tstyle.selected_name = fstyle.tstyle.list[fstyle.tstyle.selected[0] + 1]
				printHelpString("Style Added")
			end

			if fstyle.tstyle.status then
				
				if imgui.Combo('Select Style', fstyle.tstyle.selected, fstyle.tstyle.array, #fstyle.tstyle.list) then
					fstyle.applyStyle(imgui.GetStyle(), fstyle.tstyle.list[fstyle.tstyle.selected[0] + 1])
					fstyle.tstyle.selected_name = fstyle.tstyle.list[fstyle.tstyle.selected[0] + 1]
				end
				
				fstyle.StyleEditor()
			end
		end,
		function()
			imgui.TextWrapped("This program is free software: you can redistribute it and/or modify it under the terms of the \z
			GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or \z
			(at your option) any later version. \n\n\z

			This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied \z
			warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. \n\n\z

			You should have received a copy of the GNU General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.\n\n\n\z

			Copyright (C) 2022-2023 Mysterio \n")
		end,
		function()		
			imgui.Spacing()

			if imgui.BeginChild("About2") then

				imgui.Columns(2,nil,false)
				imgui.TextWrapped(string.format("%s v%s",script.this.name,script.this.version))
				imgui.Text(string.format("Build: %d",script.this.version_num))
	
				imgui.NextColumn()
				imgui.Text(string.format("Author: %s",script.this.authors[1]))
				imgui.Text(string.format("Imgui:   v%s",imgui._VERSION))
				imgui.Columns(1)

				imgui.Dummy(imgui.ImVec2(0,10))
				imgui.Dummy(imgui.ImVec2(0,10))
				imgui.TextWrapped("Minimum Resolution: 1024x768")
				imgui.TextWrapped(string.format("Your Resolution: %dx%d",resX,resY))
				imgui.TextWrapped("Maximum Resolution: 1920x1080")
				imgui.Spacing()
				imgui.TextWrapped("The Menu Will Work Properly On Other Resolutions But The GUI & Fonts Might Have Issues.")
				imgui.Dummy(imgui.ImVec2(0,10))
				imgui.Columns(2,nil,false)
				
			end
			imgui.Columns(1)
		end
	})
end

return module
