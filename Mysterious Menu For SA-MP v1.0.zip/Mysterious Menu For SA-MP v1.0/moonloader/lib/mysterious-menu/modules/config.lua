-- Mysterious Menu For SA:MP -  Mysterious Menu for Grand Theft Auto San Andreas Multiplayer
-- Copyright (C) 2022-2023 Mysterio
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.

-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.

-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.

local module = {}

module.tconfig =
{
    memory_data = {},
    misc_data   = {},
    path        = tcheatmenu.dir ..  "json/config.json",
    reset       = false,
    read        = fcommon.LoadJson("config"),
    stat_data   = {},
}


function module.Get(s,default)
    if module.tconfig.read == nil then return default end
    
    local status, rtn = pcall(function()
        local t = module.tconfig.read
        for key in s:gmatch('[^.]+') do
            if t[key] == nil then return default end
            t = t[key]
        end
  
        if t == nil then
            return default
        else
            return t
        end
    end)
 
    if status then
        return rtn
    else
        print(string.format("Error occured while getting value of %s. Returning default value %s",s,tostring(default)))
        return default
    end
end

function module.Set(t,path,value)

    local x = 0
    for key in path:gmatch('[^.]+') do
        x = x + 1
    end

    local y = 0
    for key in path:gmatch('[^.]+') do
        y = y + 1
        if x == y then
            t[key] = value
        else
            if t[key] == nil then t[key] = {} end
            t = t[key]
        end
    end
end

module.tconfig.memory_data = module.Get('tmemory_data',{})
module.tconfig.misc_data = module.Get('tmisc_data',{})

function module.SetConfigData()
    for k,v in pairs(module.tconfig.memory_data) do
        fcommon.RwMemory(tonumber(k),v[1],v[2],nil,v[3],v[4])
    end

    -- Body
    local body = module.Get("tmisc_data.Body",nil)
    if body == 1 then
        callFunction(0x439110,1,1,false)
    end
    if body == 2 then
        callFunction(0x439190,1,1,false)
        callFunction(0x439150,1,1,false)
    end
    if body == 3 then
        callFunction(0x439190,1,1,false)
    end

    -- Car & zone names
    local car_name = module.Get("tmisc_data.Display Car Names",nil)

    if car_name ~= nil then
        displayCarNames(car_name)
        fvisual.tvisual.car_names[0] = car_name
    end

    local zone_name = module.Get("tmisc_data.Display Zone Names",nil)

    if zone_name ~= nil then
        displayZoneNames(zone_name)
        fvisual.tvisual.zone_names[0] = zone_name
    end
    
end

function module.Write()
    local write_table = {}
    if not module.tconfig.reset then
        write_table =
        {
            tanimation =
            {
                fighting =
                {
                    selected = fanimation.tanimation.fighting.selected[0],
                },
                loop             = fanimation.tanimation.loop[0],
                ped              = fanimation.tanimation.ped[0],
                secondary        = fanimation.tanimation.secondary[0],
                walking =
                {
                    selected = fanimation.tanimation.walking.selected[0],
                },
            },
            tgame =
            {
                camera            =
                {    
                    fov             = fgame.tgame.camera.fov[0],   
                    movement_speed  = fgame.tgame.camera.movement_speed[0],
                },
                disable_help_popups = fgame.tgame.disable_help_popups[0],
                fps_limit           = fgame.tgame.fps_limit[0],
                script_manager      = 
                {
                    scripts         = fgame.tgame.script_manager.scripts,
                },
                ss_shortcut         = fgame.tgame.ss_shortcut[0],
                sync_system_time    = fgame.tgame.sync_system_time[0],
            },
            tmemory_data = module.tconfig.memory_data,
            tmisc_data   = module.tconfig.misc_data,
            tmenu =
            {
                auto_reload         = fmenu.tmenu.auto_reload[0],
                auto_scale          = fmenu.tmenu.auto_scale[0],
                lock_player         = fmenu.tmenu.lock_player[0],
                overlay = 
                {           
                    coordinates     = fmenu.tmenu.overlay.coordinates[0],
                    fps             = fmenu.tmenu.overlay.fps[0],
                    health          = fmenu.tmenu.overlay.health[0],
                    location        = fmenu.tmenu.overlay.location[0],
                    position_index  = fmenu.tmenu.overlay.position_index[0],
                    pos_x           = fmenu.tmenu.overlay.pos_x[0],
                    pos_y           = fmenu.tmenu.overlay.pos_y[0],
                    show            = fmenu.tmenu.overlay.show[0],
                    speed           = fmenu.tmenu.overlay.speed[0],
                },
                show_tooltips       = fmenu.tmenu.show_tooltips[0],
                show_crash_message  = fmenu.tmenu.show_crash_message[0],
            },
            tstyle =
            {
                selected_name   = fstyle.tstyle.selected_name,
            },
            tvehicle =
            {
                aircraft =
                {
                    camera       = fvehicle.tvehicle.aircraft.camera[0],
                    index        = fvehicle.tvehicle.aircraft.index,
                    spawn_in_air = fvehicle.tvehicle.aircraft.spawn_in_air[0],
                },
                first_person_camera = fvehicle.tvehicle.first_person_camera[0]
            },
            tvisual =
            {
                lock_weather     = fvisual.tvisual.lock_weather[0],
                disable_motion_blur = fvisual.tvisual.disable_motion_blur[0],
                radio_channel_names = fvisual.tvisual.radio_channel_names[0],
            },
            
        }
    end

    local file = io.open(module.tconfig.path,'w')
    if file then
        file:write(encodeJson(write_table))
        io.close(file)
    end
end

return module
