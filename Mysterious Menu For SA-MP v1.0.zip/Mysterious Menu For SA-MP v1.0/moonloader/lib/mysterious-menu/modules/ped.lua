-- Mysterious Menu For SA:MP -  Mysterio Menu for Grand Theft Auto San Andreas Multiplayer
-- Copyright (C) 2022-2023 KarSin

-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.

-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.

-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.

local module = {}

module.tped =
{
    filter       = imgui.ImGuiTextFilter(),
    gang =
    {
        array = {},
        index = imgui.new.int(0),
        list = 
        {
            "Ballas",
            "Grove street families",
            "Los santos vagos",
            "San fierro rifa",
            "Da nang boys",
            "Mafia",
            "Mountain cloud triad",
            "Varrio los aztecas",
            "Gang9",
            "Gang10",
        },
        names = 
        {   
            ["Ballas"] = 0,
            ["Da nang boys"] = 4,
            ["Gang9"] = 8,
            ["Gang10"] = 9,
            ["Grove street families"] = 1,
            ["Los santos vagos"] = 2,
            ["Mafia"] = 5,
            ["Mountain cloud triad"] = 6,
            ["San fierro rifa"] = 3,
            ["Varrio los aztecas"] = 7,
        },  
        wars = imgui.new.bool(fconfig.Get('tped.gang.wars',false)),
    },
    images      = {},
    names       = fcommon.LoadJson("ped"),
    path        = tcheatmenu.dir .. "peds\\",
    ped_health_display = imgui.new.bool(fconfig.Get('tped.ped_health_display',false)),
    selected    = nil,
    special     = fcommon.LoadJson("ped special"),
    type        =
    {
        array   = {},
        names   = 
        {
            "CIVMALE",
            "CIVFEMALE",
            "COP",
            "Ballas",
            "Grove Street Families",
            "Los Santos Vagos",
            "San Fierro Rifa",
            "Da Nang Boys",
            "Mafia",
            "Mountain Cloud Triads",
            "Varrio Los Aztecas",
            "GANG9",
            "GANG10",
            "DEALER",
            "EMERGENCY",
            "FIREMAN",
            "CRIMINAL",
            "BUM",
            "SPECIAL",
            "PROSTITUTE"
        },
        index   = imgui.new.int(fconfig.Get('tped.type.index',0)),
    },
}

module.tped.type.array = imgui.new['const char*'][#module.tped.type.names](module.tped.type.names)
module.tped.gang.array = imgui.new['const char*'][#module.tped.gang.list](module.tped.gang.list)

function module.PedHealthDisplay()
    while true do

        if module.tped.ped_health_display[0] then
            local result, char = getCharPlayerIsTargeting(PLAYER_HANDLE)

            if result then

                local health = getCharHealth(char)
                local x,y,z = getCharCoordinates(char)
                local screenX,screenY = convert3DCoordsToScreen(x,y,z+1.0)
                mad.draw_text(tostring(health),screenX,screenY,1,0.8,0.4,0,false,false,false,255,255,255,255,false)

            end
        end
        wait(0)
    end
end

function module.PedMain()     
        imgui.Spacing()
        fcommon.Tabs("Ped",{"Checkboxes"},{
            function()
                imgui.Columns(2,nil,false)
                fcommon.CheckBoxVar("Display Target Health",module.tped.ped_health_display)
            end
        })
end
return module
